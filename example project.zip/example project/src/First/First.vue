<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1" hotspotColumnWidth="70px">

            <template #hotspots>

                <iv-toggle-hotspot position="bottom" title="x-value">
                    <iv-slider ref="slider" @sliderChanged="change" theme="Lime" :min="0" :max="150" :init_val="0" :step="0.1" />
                </iv-toggle-hotspot>

            </template> 

            <iv-pane position="left" format="push">
                <iv-sidebar-content>
                    <iv-sidebar-section title="Theory" theme="Blue" icon="futbol">
                    <p>
                    The SUVAT equations are one of the first equations that you learn in mechanics.
                    With these equations, you can easily predict the motion of a ball under constant acceleration. 
                    For us, the most important equation is
                    <iv-equation-box 
                        :stylise="true" 
                        equation="s = ut + at^2"
                    />, where u is the initial velocity and a is the acceleration. 
                    </p>
                    </iv-sidebar-section>
                </iv-sidebar-content>
            </iv-pane>

            <div style="display: block;"> 
                <canvas id="ball-canvas" width="300" height="300"></canvas>
                A bouncing ball!
            </div>

        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
export default {
    name:"first",
    data(){
        return {
            pageName:"First",
            vue_config,
            x: 2
        }
    },
    mounted() {
        let _this = this;

        let canvas = document.getElementById("ball-canvas");
        let ctx = canvas.getContext("2d");

        canvas.style.border = '1px solid #000'

        let t_prev = Date.now();

        ctx.fillStyle = "orange";

        let a = 9.81
        let v = 0

        let y = 2;

        function render() {
            // calculate time elapsed 
            let t_now = Date.now();
            let t = (t_now - t_prev) / 1000; // in seconds 
            t_prev = t_now;
            
            // calculate new state 
            if (y >= 29) {
                v = -Math.sqrt(2*a*25);
                y = 29;
            }
            
            y += v*t
            v += a*t
            
            // update display with new state 
            ctx.clearRect(0, 0, 300, 300);
            
            ctx.beginPath();
            ctx.arc(_this.$refs.slider.value, 10*y, 10, 0, 2*Math.PI);
            ctx.closePath();
            
            ctx.fill();
            
            // ask browser to call function asap 
            window.requestAnimationFrame(render)
        }

        // run the render function when page loads 
        document.addEventListener("DOMContentLoaded", render);
    },
    methods: {
        change: function(val) {
            this.x = val;
        }
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
</style>



