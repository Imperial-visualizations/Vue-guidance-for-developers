module.exports = {
    publicPath:'./',
    pages:{
        index:{
            entry:'src/main.js',
            title:'Index'
        },
            first:{
                entry:'src/First/main.js',
                title:'First',
                
            },
            second:{
                entry:'src/Second/main.js',
                title:'Second',
                
            },
            third:{
                entry:'src/Third/main.js',
                title:'Third',
                
            },
    }
}